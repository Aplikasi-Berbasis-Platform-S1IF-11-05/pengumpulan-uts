<?php $__env->startSection('title', 'Manage Skills'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold">My <span class="text-primary">Skills</span></h2>
            <p class="text-muted">Add or update your technical proficiency.</p>
        </div>
        <a href="<?php echo e(route('skills.create')); ?>" class="btn btn-primary">Add New Skill</a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card p-4 border-0 shadow-sm overflow-hidden">
        <div class="table-responsive">
            <table class="table table-dark table-hover mb-0">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Proficiency</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="align-middle fw-bold"><?php echo e($skill->name); ?></td>
                        <td class="align-middle"><span class="badge bg-secondary"><?php echo e($skill->category ?? 'General'); ?></span></td>
                        <td class="align-middle" style="width: 30%;">
                            <div class="d-flex align-items-center gap-2">
                                <div class="progress bg-secondary flex-grow-1" style="height: 6px;">
                                    <div class="progress-bar bg-primary" role="progressbar" style="width: <?php echo e($skill->proficiency); ?>%"></div>
                                </div>
                                <small><?php echo e($skill->proficiency); ?>%</small>
                            </div>
                        </td>
                        <td class="text-end">
                            <div class="d-flex justify-content-end gap-2">
                                <a href="<?php echo e(route('skills.edit', $skill->id)); ?>" class="btn btn-sm btn-outline-info"><i class="fas fa-edit"></i></a>
                                <form action="<?php echo e(route('skills.destroy', $skill->id)); ?>" method="POST" onsubmit="return confirm('Delete this skill?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="text-center py-4 text-muted">No skills found. Click "Add New Skill" to get started.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Data Semester 6\Praktikum ABP\UTS\2311102019_FattahRizqyAdhipratama\portofolio-uts\resources\views/admin/skills/index.blade.php ENDPATH**/ ?>