<?php $__env->startSection('title', 'Manage Achievements'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold">My <span class="text-primary">Achievements</span></h2>
            <p class="text-muted">Showcase your awards and projects.</p>
        </div>
        <a href="<?php echo e(route('achievements.create')); ?>" class="btn btn-primary">Add Achievement</a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <?php $__empty_1 = true; $__currentLoopData = $achievements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achievement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-6">
            <div class="card h-100 border-0 shadow-sm overflow-hidden">
                <div class="row g-0 h-100">
                    <div class="col-sm-4 bg-dark d-flex align-items-center justify-content-center" style="min-height: 150px;">
                        <?php if($achievement->image): ?>
                            <img src="<?php echo e(asset('storage/' . $achievement->image)); ?>" alt="Achievement" class="img-fluid object-fit-cover w-100 h-100">
                        <?php else: ?>
                            <i class="fas fa-trophy fs-1 text-primary"></i>
                        <?php endif; ?>
                    </div>
                    <div class="col-sm-8">
                        <div class="card-body d-flex flex-column h-100">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h5 class="card-title mb-0"><?php echo e($achievement->title); ?></h5>
                                <small class="text-primary fw-bold"><?php echo e($achievement->date); ?></small>
                            </div>
                            <p class="card-text text-muted small flex-grow-1"><?php echo e(Str::limit($achievement->description, 100)); ?></p>
                            <div class="d-flex gap-2 mt-3">
                                <a href="<?php echo e(route('achievements.edit', $achievement->id)); ?>" class="btn btn-sm btn-outline-info">Edit</a>
                                <form action="<?php echo e(route('achievements.destroy', $achievement->id)); ?>" method="POST" onsubmit="return confirm('Delete this achievement?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12 text-center py-5 text-muted">
            <i class="fas fa-medal display-1 mb-4 d-block"></i>
            <p>No achievements added yet.</p>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Data Semester 6\Praktikum ABP\UTS\2311102019_FattahRizqyAdhipratama\portofolio-uts\resources\views/admin/achievements/index.blade.php ENDPATH**/ ?>