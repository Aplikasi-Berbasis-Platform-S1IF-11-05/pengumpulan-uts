<?php $__env->startSection('title', 'My Portfolio'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="container">
    <section id="hero" class="row align-items-center mb-5 py-5">
        <div class="col-lg-6 mb-4 mb-lg-0">
            <h1 class="display-3 fw-bold mb-3">Fattah Rizqy Adhipratama</h1>
            <h3 class="text-white mb-4">Student</h3>
            <p class="lead text-white mb-5">Saya adalah mahasiswa teknik informatika di universitas Telkom University Purwokerto</p>
        </div>
    </section>

    <section id="skills" class="mb-5 py-5">
        <div class="text-center mb-5">
            <h2 class="display-5 fw-bold">Skill</h2>
            <div class="mx-auto bg-primary" style="height: 4px; width: 60px; border-radius: 2px;"></div>
        </div>
        <div class="row g-4">
            <?php $__empty_1 = true; $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card p-4 h-100">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="mb-0"><?php echo e($skill->name); ?></h5>
                            <span class="badge bg-primary"><?php echo e($skill->proficiency); ?>%</span>
                        </div>
                        <div class="progress bg-dark" style="height: 10px; border-radius: 5px;">
                            <div class="progress-bar bg-primary" role="progressbar" style="width: <?php echo e($skill->proficiency); ?>%" aria-valuenow="<?php echo e($skill->proficiency); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <?php if($skill->category): ?>
                            <small class="text-white-50 mt-2 d-block"><?php echo e($skill->category); ?></small>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 text-center text-white-50">Tidak ada skill yang ditambahkan</div>
            <?php endif; ?>
        </div>
    </section>
    
    <section id="achievements" class="mb-5 py-5">
        <div class="text-center mb-5">
            <h2 class="display-5 fw-bold">Recent <span class="text-primary">Achievements</span></h2>
            <div class="mx-auto bg-primary" style="height: 4px; width: 60px; border-radius: 2px;"></div>
        </div>
        <div class="row g-4">
            <?php $__empty_1 = true; $__currentLoopData = $achievements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achievement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6">
                    <div class="card h-100 border-0 shadow">
                        <div class="row g-0">
                            <?php if($achievement->image): ?>
                                <div class="col-sm-4">
                                    <img src="<?php echo e(asset('storage/' . $achievement->image)); ?>" class="img-fluid rounded-start h-100 object-fit-cover" alt="<?php echo e($achievement->title); ?>">
                                </div>
                            <?php endif; ?>
                            <div class="<?php echo e($achievement->image ? 'col-sm-8' : 'col-12'); ?>">
                                <div class="card-body p-4">
                                    <div class="text-primary fw-bold small mb-2"><?php echo e($achievement->date); ?></div>
                                    <h4 class="card-title mb-3"><?php echo e($achievement->title); ?></h4>
                                    <p class="card-text text-white-50"><?php echo e($achievement->description); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 text-center text-white-50">No achievements added yet.</div>
            <?php endif; ?>
        </div>
    </section>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .hover-primary {
        transition: color 0.2s;
    }
    .hover-primary:hover {
        color: var(--primary-color) !important;
    }
    .object-fit-cover {
        object-fit: cover;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Data Semester 6\Praktikum ABP\UTS\2311102019_FattahRizqyAdhipratama\portofolio-uts\resources\views/portfolio.blade.php ENDPATH**/ ?>