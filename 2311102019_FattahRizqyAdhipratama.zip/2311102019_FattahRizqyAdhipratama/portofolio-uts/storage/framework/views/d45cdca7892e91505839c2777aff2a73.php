<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-4">
        <div class="col-12">
            <h2 class="fw-bold">Admin <span class="text-primary">Dashboard</span></h2>
            <p class="text-muted">Manage your portfolio content here.</p>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-md-4">
            <div class="card h-100 p-4 border-0 shadow-sm text-center">
                <div class="bg-primary-subtle p-3 rounded-circle d-inline-flex mx-auto mb-3" style="width: 70px; height: 70px; align-items: center; justify-content: center;">
                    <i class="fas fa-user-circle fs-2 text-primary"></i>
                </div>
                <h3>Profile</h3>
                <p class="text-muted">Update your personal information, bio, and social links.</p>
                <a href="<?php echo e(route('profile.index')); ?>" class="btn btn-outline-primary mt-auto">Manage Profile</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card h-100 p-4 border-0 shadow-sm text-center">
                <div class="bg-success-subtle p-3 rounded-circle d-inline-flex mx-auto mb-3" style="width: 70px; height: 70px; align-items: center; justify-content: center;">
                    <i class="fas fa-tools fs-2 text-success"></i>
                </div>
                <h3>Skills</h3>
                <p class="text-muted">Add, edit, or remove your technical skills and proficiency.</p>
                <a href="<?php echo e(route('skills.index')); ?>" class="btn btn-outline-success mt-auto">Manage Skills</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card h-100 p-4 border-0 shadow-sm text-center">
                <div class="bg-warning-subtle p-3 rounded-circle d-inline-flex mx-auto mb-3" style="width: 70px; height: 70px; align-items: center; justify-content: center;">
                    <i class="fas fa-trophy fs-2 text-warning"></i>
                </div>
                <h3>Achievements</h3>
                <p class="text-muted">Showcase your awards, certifications, and major projects.</p>
                <a href="<?php echo e(route('achievements.index')); ?>" class="btn btn-outline-warning mt-auto">Manage Achievements</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Data Semester 6\Praktikum ABP\UTS\2311102019_FattahRizqyAdhipratama\portofolio-uts\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>