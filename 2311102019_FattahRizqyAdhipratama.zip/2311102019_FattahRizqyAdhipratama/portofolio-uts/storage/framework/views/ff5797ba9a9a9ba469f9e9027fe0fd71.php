<?php $__env->startSection('title', isset($skill) ? 'Edit Skill' : 'Add Skill'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="mb-4">
        <h2 class="fw-bold"><?php echo e(isset($skill) ? 'Edit' : 'Add'); ?> <span class="text-primary">Skill</span></h2>
        <p class="text-muted">Define your technical expertise.</p>
    </div>

    <div class="card p-4 glass-card border-0" style="max-width: 600px;">
        <form action="<?php echo e(isset($skill) ? route('skills.update', $skill->id) : route('skills.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php if(isset($skill)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

            <div class="mb-3">
                <label class="form-label">Skill Name</label>
                <input type="text" name="name" class="form-control bg-dark text-white border-secondary" value="<?php echo e($skill->name ?? old('name')); ?>" required placeholder="e.g. Laravel, React, Photoshop">
            </div>

            <div class="mb-3">
                <label class="form-label">Category</label>
                <input type="text" name="category" class="form-control bg-dark text-white border-secondary" value="<?php echo e($skill->category ?? old('category')); ?>" placeholder="e.g. Frontend, Backend, Design">
            </div>

            <div class="mb-4">
                <label class="form-label">Proficiency (%)</label>
                <input type="number" name="proficiency" class="form-control bg-dark text-white border-secondary" value="<?php echo e($skill->proficiency ?? old('proficiency', 0)); ?>" min="0" max="100" required>
                <div class="form-text text-muted">A value between 0 and 100.</div>
            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary"><?php echo e(isset($skill) ? 'Update Skill' : 'Save Skill'); ?></button>
                <a href="<?php echo e(route('skills.index')); ?>" class="btn btn-outline-light">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Data Semester 6\Praktikum ABP\UTS\2311102019_FattahRizqyAdhipratama\portofolio-uts\resources\views/admin/skills/create.blade.php ENDPATH**/ ?>