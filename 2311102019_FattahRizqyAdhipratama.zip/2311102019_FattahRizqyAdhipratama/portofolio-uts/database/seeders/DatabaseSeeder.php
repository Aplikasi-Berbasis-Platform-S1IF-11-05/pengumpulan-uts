<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Admin User
        \App\Models\User::factory()->create([
            'name' => 'Admin Portfolio',
            'email' => 'admin@gmail.com',
            'password' => \Illuminate\Support\Facades\Hash::make('admin123'),
        ]);

        // Default Profile
        \App\Models\Profile::create([
            'name' => 'John Doe',
            'role' => 'Fullstack Web Developer',
            'bio' => 'I am a passionate developer with expertise in Laravel, React, and modern web technologies. I love building clean, efficient, and user-friendly applications.',
            'email' => 'admin@gmail.com',
            'phone' => '+62 812 3456 7890',
            'address' => 'Jakarta, Indonesia',
            'linkedin_url' => 'https://linkedin.com/in/johndoe',
            'github_url' => 'https://github.com/johndoe',
        ]);
    }
}
