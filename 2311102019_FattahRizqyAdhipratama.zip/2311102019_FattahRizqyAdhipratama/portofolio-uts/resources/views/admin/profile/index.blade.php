@extends('layouts.app')

@section('title', 'Manage Profile')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold">My <span class="text-primary">Profile</span></h2>
            <p class="text-muted">Manage your personal information.</p>
        </div>
        @if($profile)
            <a href="{{ route('profile.edit', $profile->id) }}" class="btn btn-primary">Edit Profile</a>
        @else
            <p class="text-danger">Profile not initialized. Please seed the database.</p>
        @endif
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    @if($profile)
    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card p-4 text-center">
                @if($profile->photo)
                    <img src="{{ asset('storage/' . $profile->photo) }}" alt="Photo" class="img-fluid rounded-circle mb-3 border border-primary border-2 mx-auto" style="width: 150px; height: 150px; object-fit: cover;">
                @else
                    <div class="bg-secondary rounded-circle mb-3 mx-auto d-flex align-items-center justify-content-center" style="width: 150px; height: 150px;">
                        <i class="fas fa-user fs-1"></i>
                    </div>
                @endif
                <h4>{{ $profile->name }}</h4>
                <p class="text-primary fw-bold">{{ $profile->role }}</p>
                <div class="d-flex justify-content-center gap-3 fs-5">
                    @if($profile->linkedin_url) <a href="{{ $profile->linkedin_url }}" class="text-light"><i class="fab fa-linkedin"></i></a> @endif
                    @if($profile->github_url) <a href="{{ $profile->github_url }}" class="text-light"><i class="fab fa-github"></i></a> @endif
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card p-4 h-100">
                <h5 class="border-bottom pb-2 mb-3">Biography</h5>
                <p class="text-muted">{{ $profile->bio }}</p>
                
                <h5 class="border-bottom pb-2 mb-3 mt-4">Contact Details</h5>
                <div class="row">
                    <div class="col-sm-6 mb-3">
                        <small class="text-primary d-block">Email</small>
                        <span>{{ $profile->email }}</span>
                    </div>
                    <div class="col-sm-6 mb-3">
                        <small class="text-primary d-block">Phone</small>
                        <span>{{ $profile->phone ?? '-' }}</span>
                    </div>
                    <div class="col-12 mb-3">
                        <small class="text-primary d-block">Address</small>
                        <span>{{ $profile->address ?? '-' }}</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endif
</div>
@endsection
