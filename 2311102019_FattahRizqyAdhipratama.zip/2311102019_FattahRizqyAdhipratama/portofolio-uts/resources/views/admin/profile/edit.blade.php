@extends('layouts.app')

@section('title', 'Edit Profile')

@section('content')
<div class="container">
    <div class="mb-4">
        <h2 class="fw-bold">Edit <span class="text-primary">Profile</span></h2>
        <p class="text-muted">Update your personal information.</p>
    </div>

    <div class="card p-4 glass-card border-0">
        <form action="{{ route('profile.update', $profile->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="name" class="form-control bg-dark text-white border-secondary" value="{{ $profile->name }}" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Role</label>
                    <input type="text" name="role" class="form-control bg-dark text-white border-secondary" value="{{ $profile->role }}" required>
                </div>
                <div class="col-12 mb-3">
                    <label class="form-label">Biography</label>
                    <textarea name="bio" class="form-control bg-dark text-white border-secondary" rows="4" required>{{ $profile->bio }}</textarea>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control bg-dark text-white border-secondary" value="{{ $profile->email }}" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Phone</label>
                    <input type="text" name="phone" class="form-control bg-dark text-white border-secondary" value="{{ $profile->phone }}">
                </div>
                <div class="col-12 mb-3">
                    <label class="form-label">Address</label>
                    <input type="text" name="address" class="form-control bg-dark text-white border-secondary" value="{{ $profile->address }}">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">LinkedIn URL</label>
                    <input type="url" name="linkedin_url" class="form-control bg-dark text-white border-secondary" value="{{ $profile->linkedin_url }}">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">GitHub URL</label>
                    <input type="url" name="github_url" class="form-control bg-dark text-white border-secondary" value="{{ $profile->github_url }}">
                </div>
                <div class="col-12 mb-4">
                    <label class="form-label">Profile Photo</label>
                    <input type="file" name="photo" class="form-control bg-dark text-white border-secondary">
                    <small class="text-muted">Current photo: {{ $profile->photo ?? 'None' }}</small>
                </div>
            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">Save Changes</button>
                <a href="{{ route('profile.index') }}" class="btn btn-outline-light">Cancel</a>
            </div>
        </form>
    </div>
</div>
@endsection

@section('styles')
<style>
    .form-control:focus {
        background-color: #1e293b;
        color: white;
        border-color: var(--primary-color);
    }
</style>
@endsection
