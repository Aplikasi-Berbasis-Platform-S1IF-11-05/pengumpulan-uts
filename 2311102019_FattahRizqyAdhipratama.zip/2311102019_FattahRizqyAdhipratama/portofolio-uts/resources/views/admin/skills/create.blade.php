@extends('layouts.app')

@section('title', isset($skill) ? 'Edit Skill' : 'Add Skill')

@section('content')
<div class="container">
    <div class="mb-4">
        <h2 class="fw-bold">{{ isset($skill) ? 'Edit' : 'Add' }} <span class="text-primary">Skill</span></h2>
        <p class="text-muted">Define your technical expertise.</p>
    </div>

    <div class="card p-4 glass-card border-0" style="max-width: 600px;">
        <form action="{{ isset($skill) ? route('skills.update', $skill->id) : route('skills.store') }}" method="POST">
            @csrf
            @if(isset($skill)) @method('PUT') @endif

            <div class="mb-3">
                <label class="form-label">Skill Name</label>
                <input type="text" name="name" class="form-control bg-dark text-white border-secondary" value="{{ $skill->name ?? old('name') }}" required placeholder="e.g. Laravel, React, Photoshop">
            </div>

            <div class="mb-3">
                <label class="form-label">Category</label>
                <input type="text" name="category" class="form-control bg-dark text-white border-secondary" value="{{ $skill->category ?? old('category') }}" placeholder="e.g. Frontend, Backend, Design">
            </div>

            <div class="mb-4">
                <label class="form-label">Proficiency (%)</label>
                <input type="number" name="proficiency" class="form-control bg-dark text-white border-secondary" value="{{ $skill->proficiency ?? old('proficiency', 0) }}" min="0" max="100" required>
                <div class="form-text text-muted">A value between 0 and 100.</div>
            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">{{ isset($skill) ? 'Update Skill' : 'Save Skill' }}</button>
                <a href="{{ route('skills.index') }}" class="btn btn-outline-light">Cancel</a>
            </div>
        </form>
    </div>
</div>
@endsection
