@extends('layouts.app')

@section('title', 'Manage Skills')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold">My <span class="text-primary">Skills</span></h2>
            <p class="text-muted">Add or update your technical proficiency.</p>
        </div>
        <a href="{{ route('skills.create') }}" class="btn btn-primary">Add New Skill</a>
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <div class="card p-4 border-0 shadow-sm overflow-hidden">
        <div class="table-responsive">
            <table class="table table-dark table-hover mb-0">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Proficiency</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($skills as $skill)
                    <tr>
                        <td class="align-middle fw-bold">{{ $skill->name }}</td>
                        <td class="align-middle"><span class="badge bg-secondary">{{ $skill->category ?? 'General' }}</span></td>
                        <td class="align-middle" style="width: 30%;">
                            <div class="d-flex align-items-center gap-2">
                                <div class="progress bg-secondary flex-grow-1" style="height: 6px;">
                                    <div class="progress-bar bg-primary" role="progressbar" style="width: {{ $skill->proficiency }}%"></div>
                                </div>
                                <small>{{ $skill->proficiency }}%</small>
                            </div>
                        </td>
                        <td class="text-end">
                            <div class="d-flex justify-content-end gap-2">
                                <a href="{{ route('skills.edit', $skill->id) }}" class="btn btn-sm btn-outline-info"><i class="fas fa-edit"></i></a>
                                <form action="{{ route('skills.destroy', $skill->id) }}" method="POST" onsubmit="return confirm('Delete this skill?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="4" class="text-center py-4 text-muted">No skills found. Click "Add New Skill" to get started.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
