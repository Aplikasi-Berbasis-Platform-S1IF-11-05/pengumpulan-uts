@extends('layouts.app')

@section('title', 'Edit Skill')

@section('content')
<div class="container">
    <div class="mb-4">
        <h2 class="fw-bold">Edit <span class="text-primary">Skill</span></h2>
        <p class="text-muted">Update your technical expertise.</p>
    </div>

    <div class="card p-4 glass-card border-0" style="max-width: 600px;">
        <form action="{{ route('skills.update', $skill->id) }}" method="POST">
            @csrf
            @method('PUT')

            <div class="mb-3">
                <label class="form-label">Skill Name</label>
                <input type="text" name="name" class="form-control bg-dark text-white border-secondary" value="{{ $skill->name }}" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Category</label>
                <input type="text" name="category" class="form-control bg-dark text-white border-secondary" value="{{ $skill->category }}">
            </div>

            <div class="mb-4">
                <label class="form-label">Proficiency (%)</label>
                <input type="number" name="proficiency" class="form-control bg-dark text-white border-secondary" value="{{ $skill->proficiency }}" min="0" max="100" required>
            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">Update Skill</button>
                <a href="{{ route('skills.index') }}" class="btn btn-outline-light">Cancel</a>
            </div>
        </form>
    </div>
</div>
@endsection
