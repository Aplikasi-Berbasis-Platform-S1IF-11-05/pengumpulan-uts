@extends('layouts.app')

@section('title', isset($achievement) ? 'Edit Achievement' : 'Add Achievement')

@section('content')
<div class="container">
    <div class="mb-4">
        <h2 class="fw-bold">{{ isset($achievement) ? 'Edit' : 'Add' }} <span class="text-primary">Achievement</span></h2>
        <p class="text-muted">Share your success stories.</p>
    </div>

    <div class="card p-4 glass-card border-0" style="max-width: 700px;">
        <form action="{{ isset($achievement) ? route('achievements.update', $achievement->id) : route('achievements.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            @if(isset($achievement)) @method('PUT') @endif

            <div class="mb-3">
                <label class="form-label">Title</label>
                <input type="text" name="title" class="form-control bg-dark text-white border-secondary" value="{{ $achievement->title ?? old('title') }}" required placeholder="e.g. Winner of Hackathon 2023">
            </div>

            <div class="mb-3">
                <label class="form-label">Date/Year</label>
                <input type="text" name="date" class="form-control bg-dark text-white border-secondary" value="{{ $achievement->date ?? old('date') }}" placeholder="e.g. June 2023 or 2023">
            </div>

            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control bg-dark text-white border-secondary" rows="4" placeholder="Briefly describe the achievement...">{{ $achievement->description ?? old('description') }}</textarea>
            </div>

            <div class="mb-4">
                <label class="form-label">Achievement Image (Optional)</label>
                <input type="file" name="image" class="form-control bg-dark text-white border-secondary">
                @if(isset($achievement) && $achievement->image)
                    <div class="mt-2">
                        <img src="{{ asset('storage/' . $achievement->image) }}" alt="Preview" class="img-thumbnail" style="max-width: 200px;">
                    </div>
                @endif
            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">{{ isset($achievement) ? 'Update' : 'Save' }} Achievement</button>
                <a href="{{ route('achievements.index') }}" class="btn btn-outline-light">Cancel</a>
            </div>
        </form>
    </div>
</div>
@endsection
