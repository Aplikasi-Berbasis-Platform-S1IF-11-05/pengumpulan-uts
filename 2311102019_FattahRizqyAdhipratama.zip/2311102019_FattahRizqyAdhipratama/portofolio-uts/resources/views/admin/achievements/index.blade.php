@extends('layouts.app')

@section('title', 'Manage Achievements')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold">My <span class="text-primary">Achievements</span></h2>
            <p class="text-muted">Showcase your awards and projects.</p>
        </div>
        <a href="{{ route('achievements.create') }}" class="btn btn-primary">Add Achievement</a>
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <div class="row g-4">
        @forelse($achievements as $achievement)
        <div class="col-md-6">
            <div class="card h-100 border-0 shadow-sm overflow-hidden">
                <div class="row g-0 h-100">
                    <div class="col-sm-4 bg-dark d-flex align-items-center justify-content-center" style="min-height: 150px;">
                        @if($achievement->image)
                            <img src="{{ asset('storage/' . $achievement->image) }}" alt="Achievement" class="img-fluid object-fit-cover w-100 h-100">
                        @else
                            <i class="fas fa-trophy fs-1 text-primary"></i>
                        @endif
                    </div>
                    <div class="col-sm-8">
                        <div class="card-body d-flex flex-column h-100">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h5 class="card-title mb-0">{{ $achievement->title }}</h5>
                                <small class="text-primary fw-bold">{{ $achievement->date }}</small>
                            </div>
                            <p class="card-text text-muted small flex-grow-1">{{ Str::limit($achievement->description, 100) }}</p>
                            <div class="d-flex gap-2 mt-3">
                                <a href="{{ route('achievements.edit', $achievement->id) }}" class="btn btn-sm btn-outline-info">Edit</a>
                                <form action="{{ route('achievements.destroy', $achievement->id) }}" method="POST" onsubmit="return confirm('Delete this achievement?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @empty
        <div class="col-12 text-center py-5 text-muted">
            <i class="fas fa-medal display-1 mb-4 d-block"></i>
            <p>No achievements added yet.</p>
        </div>
        @endforelse
    </div>
</div>
@endsection
