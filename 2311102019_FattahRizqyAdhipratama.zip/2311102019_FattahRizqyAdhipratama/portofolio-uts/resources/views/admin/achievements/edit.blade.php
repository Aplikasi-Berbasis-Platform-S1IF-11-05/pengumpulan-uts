@extends('layouts.app')

@section('title', 'Edit Achievement')

@section('content')
<div class="container">
    <div class="mb-4">
        <h2 class="fw-bold">Edit <span class="text-primary">Achievement</span></h2>
        <p class="text-muted">Update your success story.</p>
    </div>

    <div class="card p-4 glass-card border-0" style="max-width: 700px;">
        <form action="{{ route('achievements.update', $achievement->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <div class="mb-3">
                <label class="form-label">Title</label>
                <input type="text" name="title" class="form-control bg-dark text-white border-secondary" value="{{ $achievement->title }}" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Date/Year</label>
                <input type="text" name="date" class="form-control bg-dark text-white border-secondary" value="{{ $achievement->date }}">
            </div>

            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control bg-dark text-white border-secondary" rows="4">{{ $achievement->description }}</textarea>
            </div>

            <div class="mb-4">
                <label class="form-label">Achievement Image</label>
                <input type="file" name="image" class="form-control bg-dark text-white border-secondary">
                @if($achievement->image)
                    <div class="mt-2">
                        <img src="{{ asset('storage/' . $achievement->image) }}" alt="Current Image" class="img-thumbnail" style="max-width: 200px;">
                    </div>
                @endif
            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">Update Achievement</button>
                <a href="{{ route('achievements.index') }}" class="btn btn-outline-light">Cancel</a>
            </div>
        </form>
    </div>
</div>
@endsection
