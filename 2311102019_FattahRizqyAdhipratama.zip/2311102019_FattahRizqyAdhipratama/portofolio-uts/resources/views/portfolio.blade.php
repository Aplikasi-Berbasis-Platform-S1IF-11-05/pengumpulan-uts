@extends('layouts.app')
@section('title', 'My Portfolio')
@section('content')
@include('layouts.navbar')
<div class="container">
    <section id="hero" class="row align-items-center mb-5 py-5">
        <div class="col-lg-6 mb-4 mb-lg-0">
            <h1 class="display-3 fw-bold mb-3">Fattah Rizqy Adhipratama</h1>
            <h3 class="text-white mb-4">Student</h3>
            <p class="lead text-white mb-5">Saya adalah mahasiswa teknik informatika di universitas Telkom University Purwokerto</p>
        </div>
    </section>

    <section id="skills" class="mb-5 py-5">
        <div class="text-center mb-5">
            <h2 class="display-5 fw-bold">Skill</h2>
            <div class="mx-auto bg-primary" style="height: 4px; width: 60px; border-radius: 2px;"></div>
        </div>
        <div class="row g-4">
            @forelse($skills as $skill)
                <div class="col-md-6 col-lg-4">
                    <div class="card p-4 h-100">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="mb-0">{{ $skill->name }}</h5>
                            <span class="badge bg-primary">{{ $skill->proficiency }}%</span>
                        </div>
                        <div class="progress bg-dark" style="height: 10px; border-radius: 5px;">
                            <div class="progress-bar bg-primary" role="progressbar" style="width: {{ $skill->proficiency }}%" aria-valuenow="{{ $skill->proficiency }}" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        @if($skill->category)
                            <small class="text-white-50 mt-2 d-block">{{ $skill->category }}</small>
                        @endif
                    </div>
                </div>
            @empty
                <div class="col-12 text-center text-white-50">Tidak ada skill yang ditambahkan</div>
            @endforelse
        </div>
    </section>
    
    <section id="achievements" class="mb-5 py-5">
        <div class="text-center mb-5">
            <h2 class="display-5 fw-bold">Recent <span class="text-primary">Achievements</span></h2>
            <div class="mx-auto bg-primary" style="height: 4px; width: 60px; border-radius: 2px;"></div>
        </div>
        <div class="row g-4">
            @forelse($achievements as $achievement)
                <div class="col-md-6">
                    <div class="card h-100 border-0 shadow">
                        <div class="row g-0">
                            @if($achievement->image)
                                <div class="col-sm-4">
                                    <img src="{{ asset('storage/' . $achievement->image) }}" class="img-fluid rounded-start h-100 object-fit-cover" alt="{{ $achievement->title }}">
                                </div>
                            @endif
                            <div class="{{ $achievement->image ? 'col-sm-8' : 'col-12' }}">
                                <div class="card-body p-4">
                                    <div class="text-primary fw-bold small mb-2">{{ $achievement->date }}</div>
                                    <h4 class="card-title mb-3">{{ $achievement->title }}</h4>
                                    <p class="card-text text-white-50">{{ $achievement->description }}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @empty
                <div class="col-12 text-center text-white-50">No achievements added yet.</div>
            @endforelse
        </div>
    </section>
    
@endsection

@section('styles')
<style>
    .hover-primary {
        transition: color 0.2s;
    }
    .hover-primary:hover {
        color: var(--primary-color) !important;
    }
    .object-fit-cover {
        object-fit: cover;
    }
</style>
@endsection
