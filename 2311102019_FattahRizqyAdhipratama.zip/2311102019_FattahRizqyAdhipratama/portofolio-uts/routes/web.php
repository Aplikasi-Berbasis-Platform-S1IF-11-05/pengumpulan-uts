<?php

use App\Http\Controllers\PortfolioController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\Admin\ProfileController;
use App\Http\Controllers\Admin\SkillController;
use App\Http\Controllers\Admin\AchievementController;
use Illuminate\Support\Facades\Route;

// Public Portfolio
Route::get('/', [PortfolioController::class, 'index'])->name('portfolio');

// Authentication
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Admin Dashboard (Protected)
Route::middleware(['auth'])->prefix('admin')->group(function () {
    Route::get('/dashboard', function () {
        return view('admin.dashboard');
    })->name('admin.dashboard');

    Route::resource('profile', ProfileController::class)->only(['index', 'edit', 'update']);
    Route::resource('skills', SkillController::class);
    Route::resource('achievements', AchievementController::class);
});
