<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $user->name ?? 'Portfolio' }} - {{ $user->email ?? '' }}</title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Bebas+Neue&family=Inter:wght@400;700;900&family=Space+Grotesk:wght@400;700&display=swap" rel="stylesheet">
</head>
<body style="font-family: 'Inter', sans-serif; background-color: #fff; margin: 0; padding: 0;">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'display': ['Bebas Neue', 'sans-serif'],
                        'display-alt': ['Anton', 'sans-serif'],
                        'grotesk': ['Space Grotesk', 'sans-serif'],
                    }
                }
            }
        }
    </script>

    <!-- Custom CSS -->
    <style>
        /* Hard borders and shadows - Neo-Brutalism */
        .brutal-box {
            border: 4px solid #000;
            background: #fff;
            box-shadow: 8px 8px 0 #000;
            transition: all 0.2s;
        }
        
        .brutal-box:hover {
            transform: translate(-2px, -2px);
            box-shadow: 10px 10px 0 #000;
        }
        
        .brutal-button {
            display: inline-block;
            padding: 0.75rem 2rem;
            font-weight: 900;
            border: 3px solid #000;
            background: #ff00ff;
            color: #000;
            text-transform: uppercase;
            box-shadow: 4px 4px 0 #000;
            cursor: pointer;
            transition: all 0.1s;
            text-decoration: none;
        }
        
        .brutal-button:hover {
            transform: translate(2px, 2px);
            box-shadow: 2px 2px 0 #000;
        }
        
        .brutal-button:active {
            transform: translate(4px, 4px);
            box-shadow: 0 0 0 #000;
        }
        
        .brutal-button-green {
            background: #00ff00;
            color: #000;
        }
        
        .brutal-button-yellow {
            background: #ffff00;
            color: #000;
        }
        
        .brutal-button-blue {
            background: #00ffff;
            color: #000;
        }
        
        .brutal-button-orange {
            background: #ff9900;
            color: #000;
        }
        
        /* Stripe background pattern */
        .striped-bg {
            background: repeating-linear-gradient(
                45deg,
                #ffcc00,
                #ffcc00 20px,
                #000 20px,
                #000 40px
            );
        }
        
        /* Offset text effect */
        .offset-text {
            position: relative;
            display: inline-block;
        }
        
        .offset-text::after {
            content: attr(data-text);
            position: absolute;
            left: 2px;
            top: 2px;
            color: #000;
            z-index: -1;
        }
        
        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 12px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border: 2px solid #000;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #000;
        }
        
        /* Glitch effect on hover */
        .glitch {
            position: relative;
        }
        
        .glitch:hover::before,
        .glitch:hover::after {
            content: attr(data-text);
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
        }
        
        .glitch:hover::before {
            animation: glitch-1 0.3s infinite linear alternate-reverse;
            color: #ff00ff;
            z-index: -1;
        }
        
        .glitch:hover::after {
            animation: glitch-2 0.3s infinite linear alternate-reverse;
            color: #00ffff;
            z-index: -2;
        }
        
        @keyframes glitch-1 {
            0% { clip-path: inset(40% 0 61% 0); transform: translate(-2px, 2px); }
            20% { clip-path: inset(92% 0 1% 0); transform: translate(2px, -2px); }
            40% { clip-path: inset(43% 0 1% 0); transform: translate(-2px, 2px); }
            60% { clip-path: inset(25% 0 58% 0); transform: translate(2px, -2px); }
            80% { clip-path: inset(54% 0 7% 0); transform: translate(-2px, 2px); }
            100% { clip-path: inset(58% 0 43% 0); transform: translate(2px, -2px); }
        }
        
        @keyframes glitch-2 {
            0% { clip-path: inset(65% 0 36% 0); transform: translate(2px, -2px); }
            20% { clip-path: inset(79% 0 18% 0); transform: translate(-2px, 2px); }
            40% { clip-path: inset(36% 0 64% 0); transform: translate(2px, -2px); }
            60% { clip-path: inset(38% 0 50% 0); transform: translate(-2px, 2px); }
            80% { clip-path: inset(73% 0 14% 0); transform: translate(2px, -2px); }
            100% { clip-path: inset(30% 0 70% 0); transform: translate(-2px, 2px); }
        }
        
        /* Marquee animation */
        @keyframes marquee {
            0% { transform: translateX(0); }
            100% { transform: translateX(-50%); }
        }
        
        .animate-marquee {
            animation: marquee 20s linear infinite;
        }
        
        /* Custom scrollbar - Firefox */
        * {
            scrollbar-width: auto;
            scrollbar-color: #000 #f1f1f1;
        }
    </style>
</head>
<body class="bg-white text-black">
    <!-- Hero Section -->
    <header class="py-12 px-4 md:px-8 lg:px-16 border-b-4 border-black">
        <div class="max-w-7xl mx-auto">
            <div class="flex flex-col md:flex-row items-center gap-8">
                <!-- Profile Image -->
                <div class="flex-shrink-0">
                    <div class="brutal-box w-48 h-48 md:w-64 md:h-64 p-1" style="background-image: linear-gradient(135deg, #ffcc00, #ff00ff, #00ffff, #00ff00);">
                        <div class="w-full h-full bg-black flex items-center justify-center">
                            <span class="font-display-alt text-6xl md:text-8xl text-white">{{ strtoupper(substr($user->name ?? 'U', 0, 1)) }}</span>
                        </div>
                    </div>
                </div>
                
                <!-- Hero Text -->
                <div class="flex-grow text-center md:text-left">
                    <h1 class="font-display text-5xl md:text-7xl lg:text-9xl mb-2 glitch" data-text="{{ $user->name ?? 'UNKNOWN' }}">
                        {{ $user->name ?? 'UNKNOWN' }}
                    </h1>
                    <p class="font-grotesk text-xl md:text-2xl font-bold mb-4 text-pink-600 offset-text" data-text="{{ $user->email ?? '' }}">
                        {{ $user->email ?? '' }}
                    </p>
                    @if($user->birth_date)
                        <p class="font-grotesk text-lg md:text-xl font-bold text-cyan-600">
                            Born: {{ \Carbon\Carbon::parse($user->birth_date)->format('F d, Y') }}
                        </p>
                    @endif
                </div>
            </div>
        </div>
    </header>

    <!-- Skills Section -->
    <section class="py-16 px-4 md:px-8 lg:px-16 border-b-4 border-black bg-yellow-100">
        <div class="max-w-7xl mx-auto">
            <div class="flex items-center justify-between mb-8">
                <h2 class="font-display text-4xl md:text-6xl text-green-600 offset-text" data-text="SKILLS">
                    SKILLS
                </h2>
                <div class="w-24 h-24 md:w-32 md:h-32 bg-black rounded-full flex items-center justify-center">
                    <span class="font-display text-white text-2xl md:text-4xl">
                        #{{ $skills->count() }}
                    </span>
                </div>
            </div>
            
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                @foreach($skills as $index => $skill)
                    <div class="brutal-box p-6" style="background-color: {{ ['#FF6B6B', '#4ECDC4', '#FFD93D', '#6BCB77', '#9B59B6', '#3498DB'][$index % 6] }};">
                        <div class="flex items-center justify-between">
                            <h3 class="font-grotesk text-2xl md:text-3xl font-black text-black uppercase">
                                {{ $skill->name }}
                            </h3>
                            <span class="font-display text-4xl text-black opacity-50">
                                {{ $index + 1 }}
                            </span>
                        </div>
                        <div class="mt-4 h-2 bg-black rounded-full overflow-hidden">
                            <div class="h-full bg-white opacity-30" style="width: {{ rand(40, 100) }}%"></div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

    <!-- Achievements Section -->
    <section class="py-16 px-4 md:px-8 lg:px-16 border-b-4 border-black bg-pink-100">
        <div class="max-w-7xl mx-auto">
            <div class="flex items-center justify-between mb-8">
                <h2 class="font-display text-4xl md:text-6xl text-purple-600 offset-text" data-text="ACHIEVEMENTS">
                    ACHIEVEMENTS
                </h2>
                <div class="w-24 h-24 md:w-32 md:h-32 bg-black rounded-full flex items-center justify-center">
                    <span class="font-display text-white text-2xl md:text-4xl">
                        #{{ $achievements->count() }}
                    </span>
                </div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                @foreach($achievements as $achievement)
                    <div class="brutal-box p-6 bg-cyan-300">
                        <h3 class="font-display-alt text-3xl md:text-4xl text-black mb-2">
                            {{ $achievement->title }}
                        </h3>
                        @if($achievement->date)
                            <div class="mb-3">
                                <span class="inline-block bg-black text-white font-grotesk font-bold px-3 py-1 text-sm">
                                    {{ \Carbon\Carbon::parse($achievement->date)->format('M Y') }}
                                </span>
                            </div>
                        @endif
                        <p class="font-grotesk text-lg text-black leading-relaxed">
                            {{ $achievement->description }}
                        </p>
                        <div class="mt-4 flex items-center">
                            <span class="text-4xl">{{ ['🏆', '🎯', '⭐', '🚀', '💎', '🔥'][$loop->index % 6] }}</span>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>


    <!-- Footer -->
    <footer class="bg-black text-white py-8 px-4">
        <div class="max-w-7xl mx-auto text-center">
            <p class="font-display text-2xl mb-2">© {{ date('Y') }} {{ $user->name ?? 'Portfolio' }}</p>
            <p class="font-grotesk text-sm opacity-75">
                Powered by Neobrutalism & Tailwind CSS
            </p>
        </div>
    </footer>
</body>
</html>
