<?php

use App\Http\Controllers\Admin\AchievementController;
use App\Http\Controllers\Admin\LoginController;
use App\Http\Controllers\Admin\SkillController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\PageController;
use Illuminate\Support\Facades\Route;

Route::get('/admin/login', [LoginController::class, 'index'])->name('admin.login');
Route::post('/admin/login', [LoginController::class, 'login'])->name('admin.login.submit');
Route::post('/admin/logout', [LoginController::class, 'logout'])->name('admin.logout');

Route::middleware(['auth'])->prefix('admin')->group(function () {
    Route::get('/user', [UserController::class, 'edit'])->name('admin.user.edit');
    Route::put('/user/edit', [UserController::class, 'update'])->name('admin.user.update');

    Route::get('/skills', [SkillController::class, 'index'])->name('admin.skills.index');
    Route::post('/skills', [SkillController::class, 'store'])->name('admin.skills.store');
    Route::delete('/skills/{id}', [SkillController::class, 'destroy'])->name('admin.skills.destroy');

    Route::get('/achievements', [AchievementController::class, 'index'])->name('admin.achievements.index');
    Route::post('/achievements', [AchievementController::class, 'store'])->name('admin.achievements.store');
    Route::delete('/achievements/{id}', [AchievementController::class, 'destroy'])->name('admin.achievements.destroy');
});

Route::get('/', [PageController::class, 'index'])->name('home');
