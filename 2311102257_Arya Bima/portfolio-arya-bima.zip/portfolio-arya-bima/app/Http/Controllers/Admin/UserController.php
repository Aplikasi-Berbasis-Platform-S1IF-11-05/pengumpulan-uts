<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    /**
     * Show the form for editing the specified resource.
     */
    public function edit()
    {
        $user = User::find(1);

        return view('admin.user.edit', compact('user'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        $user = User::find(1);

        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:users,email,'.$user->id,
            'password' => 'nullable|string|min:8|confirmed',
            'birth_date' => 'nullable|date',
        ]);

        $user->name = $validatedData['name'];
        $user->email = $validatedData['email'];
        if (! empty($validatedData['password'])) {
            $user->password = $validatedData['password'];
        }
        $user->birth_date = $validatedData['birth_date'] ?? null;
        $user->save();

        return redirect()->route('admin.user.edit', ['id' => $user->id])->with('success', 'Profile updated successfully.');
    }
}
