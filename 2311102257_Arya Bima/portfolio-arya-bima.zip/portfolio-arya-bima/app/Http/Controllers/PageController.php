<?php

namespace App\Http\Controllers;

use App\Models\Achievement;
use App\Models\Skill;
use App\Models\User;

class PageController extends Controller
{
    public function index()
    {
        $skills = Skill::all();
        $achievements = Achievement::all();
        $user = User::first(); // Get the first/primary user

        return view('portfolio', compact('skills', 'achievements', 'user'));
    }
}
